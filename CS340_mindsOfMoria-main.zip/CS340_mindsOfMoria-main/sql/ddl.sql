/******************************************************************************
********************************** CITATIONS **********************************
*******************************************************************************

We used and adapted the starter code found in the explorations for the Reset 
Database stored procedure. Google Gemini AI was also used to help create examples
for the Reset SP. 

  Link: https://canvas.oregonstate.edu/courses/1999601/pages/
        exploration-pl-slash-sql-part-2-stored-procedures-for-cud?module_item_id=25352959

  Link: https://canvas.oregonstate.edu/courses/1999601/pages/
        exploration-pl-slash-sql-part-1-sp-view-and-function?module_item_id=25352958

    The code in the above links was used and adapted to implement the RESET DATABASE
    Stored Procudure.


*****************************************************************************/

-- Project Step 2 Draft - Group 36
-- Team Members: Samuel Davidson, Kurin Schirm
-- Project Title: The Minds of Moria's Online Real-Estate Marketplace

-- displaying foreign key checks for smooth importing.
SET FOREIGN_KEY_CHECKS=0;
SET AUTOCOMMIT = 0;

-- First drop all tables if they exist (needed for clean reset)
DROP TABLE IF EXISTS Transactions;
DROP TABLE IF EXISTS Properties;
DROP TABLE IF EXISTS Agents;
DROP TABLE IF EXISTS Sellers;
DROP TABLE IF EXISTS Buyers;

-- creating Buyers table
CREATE TABLE Buyers (
    buyerID INT AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    PRIMARY KEY (buyerID)
);

-- Creating Sellers table
CREATE TABLE Sellers (
    sellerID INT AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    PRIMARY KEY (sellerID)
);

-- Creating Agents table
CREATE TABLE Agents (
    agentID INT AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    PRIMARY KEY (agentID)
);

-- Creating Properties table
CREATE TABLE Properties (
    propertyID INT AUTO_INCREMENT,
    sellerID INT NOT NULL,
    address VARCHAR(200) NOT NULL,
    price DECIMAL(12, 2) NOT NULL,
    sqft INT NOT NULL CHECK (sqft > 0 AND sqft < 10000),
    typeProperty ENUM('house', 'apartment', 'condo', 'land'),
    description VARCHAR(500),
    PRIMARY KEY (propertyID),
    FOREIGN KEY (sellerID) REFERENCES Sellers(sellerID)
    ON DELETE CASCADE ON UPDATE CASCADE
);

-- transactions
CREATE TABLE Transactions (
    transactionID INT AUTO_INCREMENT,
    propertyID INT,
    buyerID INT,
    buyerAgentID INT,
    sellerAgentID INT,
    transactionDate DATE NOT NULL,
    salePrice DECIMAL(12, 2) NOT NULL,
    PRIMARY KEY (transactionID),
    FOREIGN KEY (propertyID) REFERENCES Properties(propertyID)
    ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (buyerID) REFERENCES Buyers(buyerID)
    ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (buyerAgentID) REFERENCES Agents(agentID)
    ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (sellerAgentID) REFERENCES Agents(agentID)
    ON DELETE SET NULL ON UPDATE CASCADE
);

-- Insert sample data
INSERT INTO Buyers (name, email, password) VALUES 
('Steve Smith', 'ssmith@email.com', 'not_safe'),
('Katherine Jobs', 'katjobs@email.com', 'Strong_12$'),
('Johnny Hopkins', 'jhops@email.com', 'pets_name_8'),
('Sara Martinez', 'martinez.s@email.com', 'moms_MaiDen');

INSERT INTO Sellers (name, email, password) VALUES
('Achraf Ezra', 'a.ezra@email.com', '55_login'),
('Diego Robles', 'diego.r@gmail.com', 'fav_food_27'),
('Trent Granger', 't_granger@email.com', '4563217855'),
('Zhao Chen', 'chen.zhao@email.com', 'applesauce78');

INSERT INTO Agents (name, email, password) VALUES
('Dmitri Drozodov', 'dmi_dd@email.com', 'Hack_me_Pls'),
('Thiago Del Rio', 't.del_rio@email.com', 'redwood$8'),
('Yousef Farouq', 'yousef.f@email.com', 'kookslam_12'),
('Kenji Inoue', 'inoue.ken@email.com', 'fiFa_is_Rigged');

INSERT INTO Properties (sellerID, address, price, sqft, typeProperty, description) VALUES
(2, '555 Pinegrove Lane', 500000.00, 1200, 'condo', 'single unit'),
(1, '4289 Orange Street', 1250000.00, 2700, 'house', 'large property'),
(4, '147 Agate Avenue', 375000.00, 900, 'condo', 'single unit'),
(3, '1640 13th Street', 995000.00, 1650, 'house', 'good for families');

INSERT INTO Transactions (propertyID, buyerID, buyerAgentID, sellerAgentID, transactionDate, salePrice) VALUES
(3, 1, 1, 4, '2025-01-12', 355000.00),
(2, 3, 3, 1, '2025-03-15', 1190000.00),
(4, 4, 2, 4, '2024-12-29', 980000.00),
(1, 2, 2, 3, '2025-02-24', 500000.00);

SET FOREIGN_KEY_CHECKS=1;
COMMIT;

-- Reset procedure with complete table definitions and data
DELIMITER //
CREATE PROCEDURE ResetDatabase()
BEGIN
    -- Disable foreign key checks
    SET FOREIGN_KEY_CHECKS = 0;
    
    -- Drop tables in reverse dependency order
    DROP TABLE IF EXISTS Transactions;
    DROP TABLE IF EXISTS Properties;
    DROP TABLE IF EXISTS Agents;
    DROP TABLE IF EXISTS Sellers;
    DROP TABLE IF EXISTS Buyers;
    
    -- Recreate all tables
    CREATE TABLE Buyers (
        buyerID INT AUTO_INCREMENT,
        name VARCHAR(50) NOT NULL,
        email VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(100) NOT NULL,
        PRIMARY KEY (buyerID)
    );
    
    CREATE TABLE Sellers (
        sellerID INT AUTO_INCREMENT,
        name VARCHAR(50) NOT NULL,
        email VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(100) NOT NULL,
        PRIMARY KEY (sellerID)
    );
    
    CREATE TABLE Agents (
        agentID INT AUTO_INCREMENT,
        name VARCHAR(50) NOT NULL,
        email VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(100) NOT NULL,
        PRIMARY KEY (agentID)
    );
    
    CREATE TABLE Properties (
        propertyID INT AUTO_INCREMENT,
        sellerID INT NOT NULL,
        address VARCHAR(200) NOT NULL,
        price DECIMAL(12, 2) NOT NULL,
        sqft INT NOT NULL CHECK (sqft > 0 AND sqft < 10000),
        typeProperty ENUM('house', 'apartment', 'condo', 'land'),
        description VARCHAR(500),
        PRIMARY KEY (propertyID),
        FOREIGN KEY (sellerID) REFERENCES Sellers(sellerID)
        ON DELETE CASCADE ON UPDATE CASCADE
    );
    
    CREATE TABLE Transactions (
        transactionID INT AUTO_INCREMENT,
        propertyID INT,
        buyerID INT,
        buyerAgentID INT,
        sellerAgentID INT,
        transactionDate DATE NOT NULL,
        salePrice DECIMAL(12, 2) NOT NULL,
        PRIMARY KEY (transactionID),
        FOREIGN KEY (propertyID) REFERENCES Properties(propertyID)
        ON DELETE SET NULL ON UPDATE CASCADE,
        FOREIGN KEY (buyerID) REFERENCES Buyers(buyerID)
        ON DELETE SET NULL ON UPDATE CASCADE,
        FOREIGN KEY (buyerAgentID) REFERENCES Agents(agentID)
        ON DELETE SET NULL ON UPDATE CASCADE,
        FOREIGN KEY (sellerAgentID) REFERENCES Agents(agentID)
        ON DELETE SET NULL ON UPDATE CASCADE
    );
    
    -- Insert all sample data
    INSERT INTO Buyers (name, email, password) VALUES 
    ('Steve Smith', 'ssmith@email.com', 'not_safe'),
    ('Katherine Jobs', 'katjobs@email.com', 'Strong_12$'),
    ('Johnny Hopkins', 'jhops@email.com', 'pets_name_8'),
    ('Sara Martinez', 'martinez.s@email.com', 'moms_MaiDen');
    
    INSERT INTO Sellers (name, email, password) VALUES
    ('Achraf Ezra', 'a.ezra@email.com', '55_login'),
    ('Diego Robles', 'diego.r@gmail.com', 'fav_food_27'),
    ('Trent Granger', 't_granger@email.com', '4563217855'),
    ('Zhao Chen', 'chen.zhao@email.com', 'applesauce78');
    
    INSERT INTO Agents (name, email, password) VALUES
    ('Dmitri Drozodov', 'dmi_dd@email.com', 'Hack_me_Pls'),
    ('Thiago Del Rio', 't.del_rio@email.com', 'redwood$8'),
    ('Yousef Farouq', 'yousef.f@email.com', 'kookslam_12'),
    ('Kenji Inoue', 'inoue.ken@email.com', 'fiFa_is_Rigged');
    
    INSERT INTO Properties (sellerID, address, price, sqft, typeProperty, description) VALUES
    (2, '555 Pinegrove Lane', 500000.00, 1200, 'condo', 'single unit'),
    (1, '4289 Orange Street', 1250000.00, 2700, 'house', 'large property'),
    (4, '147 Agate Avenue', 375000.00, 900, 'condo', 'single unit'),
    (3, '1640 13th Street', 995000.00, 1650, 'house', 'good for families');
    
    INSERT INTO Transactions (propertyID, buyerID, buyerAgentID, sellerAgentID, transactionDate, salePrice) VALUES
    (3, 1, 1, 4, '2025-01-12', 355000.00),
    (2, 3, 3, 1, '2025-03-15', 1190000.00),
    (4, 4, 2, 4, '2024-12-29', 980000.00),
    (1, 2, 2, 3, '2025-02-24', 500000.00);
    
    -- Re-enable foreign key checks
    SET FOREIGN_KEY_CHECKS = 1;
END //
DELIMITER ;


