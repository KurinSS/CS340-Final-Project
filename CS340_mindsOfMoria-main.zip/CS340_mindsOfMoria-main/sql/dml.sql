/************************************/
        /* PROPERTIES */
/************************************/

-- List all Properties
SELECT * FROM Properties;

-- Get a single Property by ID
SELECT * FROM Properties
    WHERE propertyID = @propertyID;

-- Create a new Property
INSERT INTO Properties (sellerID, address, price, sqft, typeProperty, description)
    VALUES (@sellerID, @address, @price, @sqft, @typeProperty, @description);

-- Update an existing Property
UPDATE Properties SET 
    sellerID = @sellerID,
    address = @address,
    price = @price,
    sqft = @sqft,
    typeProperty = @typeProperty,
    description = @description

    WHERE propertyID = @propertyID;

-- Delete a Property
DELETE FROM Properties
    WHERE propertyID = @propertyID;



/************************************/
        /* BUYERS */
/************************************/
-- List all Buyers
SELECT * FROM Buyers;

-- Get a Buyer by ID
SELECT * FROM Buyers
    WHERE buyerID = @buyerID;

-- Create a new Buyer
INSERT INTO Buyers (name, email, password)
    VALUES (@name, @email, @password);

-- Update an existing Buyer
UPDATE Buyers SET 
    name = @name,
    email = @email,
    password = @password,

    WHERE propertyID = @propertyID;

-- Delete a Buyer
DELETE FROM Buyers
    WHERE buyerID = @buyerID;


/************************************/
        /* SELLERS */
/************************************/
-- List all Sellers
SELECT * FROM Sellers;

-- Get a Seller by ID
SELECT * FROM Sellers
    WHERE sellerID = @sellerID;

-- Create a new Seller
INSERT INTO Sellers (name, email, password)
    VALUES (@name, @email, @password);

-- Update an existing Seller
UPDATE Sellers SET 
    name = @name,
    email = @email,
    password = @password,

    WHERE sellerID = @sellerID;

-- Delete a Seller
DELETE FROM Sellers
    WHERE sellerID = @sellerID;


/************************************/
        /* AGENTS */
/************************************/
-- List all Agents
SELECT * FROM Agents;

-- Get an Agent by ID
SELECT * FROM Agents
    WHERE agentID = @agentID;

-- Create a new Agent
INSERT INTO Agents (name, email, password)
    VALUES (@name, @email, @password);

-- Update an existing Agent
UPDATE Agents SET 
    name = @name,
    email = @email,
    password = @password,

    WHERE agentID = @agentID;

-- Delete an Agent
DELETE FROM Agents
    WHERE agentID = @agentID;



/************************************/
        /* TRANSACTIONS */
/************************************/
-- List all Transactions
SELECT t.transactionID, t.salePrice,
        DATE_FORMAT(t.transactionDate, '%m-%d-%Y') as transactionDate, 
        t.propertyID, p.address, b.name as buyerName,
        s.name as sellerName, ba.name as buyerAgentName,
        sa.name as sellerAgentName
      FROM Transactions t
      JOIN Properties p ON t.propertyID = p.propertyID
      JOIN Buyers b ON t.buyerID = b.buyerID
      JOIN Sellers s ON p.sellerID = s.sellerID
      JOIN Agents ba ON t.buyerAgentID = ba.agentID
      JOIN Agents sa ON t.sellerAgentID = sa.agentID
      ORDER BY t.transactionID ASC

-- Get a Transaction by ID
SELECT * FROM Transactions
    WHERE transactionID = @transactionID;

-- Create a new Transaction
INSERT INTO Transactions (propertyID, buyerID, buyerAgentID, sellerAgentID, transactionDate, salePrice)
    VALUES (@propertyID, @buyerID, @buyerAgentID, @sellerAgentID, @transactionDate, @salePrice);

-- Update an existing Transaction
UPDATE Transactions SET 
    propertyID = @propertyID,
    buyerID = @buyerID,
    buyerAgentID = @buyerAgentID,
    sellerAgentID = @sellerAgentID,
    transactionDate = @transactionDate,
    salePrice = @salePrice

    WHERE transactionID = @transactionID;

-- Delete a Transaction
DELETE FROM Transactions
    WHERE transactionID = @transactionID;

