-- Delete a Property by ID
DELIMITER //
CREATE PROCEDURE DeleteProperty(IN prop_id INT)
BEGIN
    DELETE FROM Properties WHERE propertyID = prop_id;
END //
DELIMITER ;

-- Delete a Buyer by ID
DELIMITER //
CREATE PROCEDURE DeleteBuyer(IN buyer_id INT)
BEGIN
    DELETE FROM Buyers WHERE buyerID = buyer_id;
END //
DELIMITER ;

-- Delete a Seller by ID
DELIMITER //
CREATE PROCEDURE DeleteSeller(IN seller_id INT)
BEGIN
    DELETE FROM Sellers WHERE sellerID = seller_id;
END //
DELIMITER ;

-- Delete an Agent by ID
DELIMITER //
CREATE PROCEDURE DeleteAgent(IN agent_id INT)
BEGIN
    DELETE FROM Agents WHERE agentID = agent_id;
END //
DELIMITER ;

-- Delete a Transaction by ID
DELIMITER //
CREATE PROCEDURE DeleteTransaction(IN transaction_id INT)
BEGIN
    DELETE FROM Transactions WHERE transactionID = transaction_id;
END //
DELIMITER ;
